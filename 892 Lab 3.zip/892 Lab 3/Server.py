from concurrent import futures
import logging
import grpc
import rover_pb2
import rover_pb2_grpc
import requests
import json
import pika
from random import randint
import hashlib

# Servicer to read the map from a file and provide it to the rover
class readMap(rover_pb2_grpc.readMapServicer):
    def getMap(self, request, context):
        # Open and read the map file
        with open("C:/Users/farza/OneDrive/Desktop/892 Lab 3/map.txt", "r") as q:
            map = []
            arr = []
            for line in q:
                stripedL = line.rstrip()
                row = stripedL.split(' ')
                map.append(row)
            # Skip the first line if it is a header or not part of the map
            for i in map[1:]:
                arr.append(i)
        return rover_pb2.mapFile(map=str(arr), rows="4", cols="6")

# Servicer to read commands from an external API and append a 'C' command
class readCommand(rover_pb2_grpc.readCommandServicer):
    def getCommand(self, request, context):
        URL = "https://coe892.reev.dev/lab1/rover/" + str(request.roverNum)
        response = requests.get(URL)
        data = json.loads(response.text)
        val = data['data']['moves'] + "C"
        print("Commands: " + val)
        return rover_pb2.commandFile(val=val)

# Servicer to handle serial number requests for mines
class readSerialNum(rover_pb2_grpc.readSerialNumServicer):
    def getSerialNum(self, request, context):
        newString = "SerialNum for the mine getting dug is: " + request.serialNum
        return rover_pb2.SerialNumFile(pin=newString)

# Callback for processing messages from the Defused-Mines queue
def callback(ch, method, properties, body):
    print(" [x] Mine Pin Number From Defused-Mines Queue: %r" % body.decode())

# Main function to start the server and listen for messages
def serve():
    # Create and start the gRPC server
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    rover_pb2_grpc.add_readMapServicer_to_server(readMap(), server)
    rover_pb2_grpc.add_readCommandServicer_to_server(readCommand(), server)
    rover_pb2_grpc.add_readSerialNumServicer_to_server(readSerialNum(), server)
    server.add_insecure_port('[::]:50051')
    server.start()

    # Setup RabbitMQ connection and start consuming messages
    connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))
    channel = connection.channel()
    channel.queue_declare(queue='Defused-Mines')
    channel.basic_consume(queue='Defused-Mines', on_message_callback=callback, auto_ack=True)
    print(' [*] Waiting for messages. To exit press CTRL+C')
    channel.start_consuming()

    server.wait_for_termination()

if __name__ == '__main__':
    logging.basicConfig()
    serve()
