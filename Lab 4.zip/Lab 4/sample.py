import requests 

print("Map Commands:\n1. See map\n2. Update Rows / Cols\n")
print("Mine Commands:\n3. See all mines\n4. See a specific mine\n5. Delete a mine\n6. Create a mine\n7. Update a mine\n") 
print("Rover Commands:\n8. See all rovers\n9. See a specific rover\n10. Create a rover\n11. Delete a rover\n12. Update a rovers commands\n13. Dispatch a rover") 

def main():
  while(1):
    option = int(input('\nEnter command: '))
    if option == 1:
      getMap()
    elif option == 2:
      updateMap()
    elif option == 3:
      getMines()
    elif option == 4:
      getSpecificMine()
    elif option == 5:
      deleteMine()
    elif option == 6:
      createMine()
    elif option == 7:
      print("Option 13 selected")
    else:
      print("Invalid option selected")


def getMap():
  request = requests.get('http://127.0.0.1:8000/map')
  
  if request.status_code == 200:
    data = request.json()
    print(f'Rows: {data['rows']}, Cols: {data['cols']}')
    print('Map:')
    for row in data['map']:
      currLine = ""
      for num in row:
        if num == 1:
          currLine += '*'
        else:
          currLine += '0'
        currLine += ' '
      print(currLine)
  else:
      print(f"Error: {request.status_code}")

def updateMap():
  r = int(input('New rows: '))
  c = int(input('New cols: '))
  data = {'r' : r, 'c' : c}

  request = requests.put('http://127.0.0.1:8000/map', params=data)
  if request.status_code == 200:
    print("Map updated: ")
    print(request.json())
  else:
      print(f"Error: {request.status_code}")

def getMines():
  request = requests.get('http://127.0.0.1:8000/mines')

  if request.status_code == 200:
    print(request.json())
  else:
      print(f"Error: {request.status_code}")

def getSpecificMine():
  id = input('Enter mine id: ')
  request = requests.get(f'http://127.0.0.1:8000/mines/{id}')

  if request.status_code == 200:
    print(request.json())
  else:
      print(f"Error: {request.status_code}")

def deleteMine():
  id = input('Enter mine id: ')
  request = requests.delete(f'http://127.0.0.1:8000/mines/{id}')

  if request.status_code == 200:
    print(request.json())
  else:
      print(f"Error: {request.status_code}")

def createMine():
  serialNum = input('Serial Number: ')
  row = input('Row: ')
  col = input('Col: ')

  payload = {'serialNum': serialNum, 'row': row, 'col': col}

  request = requests.post('http://127.0.0.1:8000/mines', json=payload)
  if request.status_code == 200:
    print("Mine created")
  else:
    print(f"Error: {request.status_code}")





  


if __name__ == "__main__":
  main()