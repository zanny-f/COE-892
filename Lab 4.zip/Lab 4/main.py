from fastapi import FastAPI, HTTPException
import random

from pydantic import ValidationError, BaseModel

app = FastAPI()

# I assume the mine's id and serial number are interchangeable
# The serial number is just the row + col of the mine as a str

# setting global variables
rows, cols, map = 0, 0, []
mines = {}
rovers = {}

# Loading map
@app.get('/map')
async def getMap():
  global rows, cols, map, mines

  if not map: 
      with open('map.txt') as f:
        rows, cols = [int(x) for x in next(f).split()] # read first line
        map = [[int(x) for x in line.split()] for line in f]

      for i in range(rows):
        for j in range(cols):
          if map[i][j] != 0:
            serialNum = str(i) + str(j)
            mines[serialNum] = {'row': i, 'col': j}

  return {'rows': rows, 'cols': cols, 'map': map}

# Updating rows / cols
@app.put('/map')
async def putMap(r: int, c: int):
  global rows, cols
  rows, cols = r, c
  return {'rows': rows, 'cols': cols, 'map': map}


# Getting all mines
@app.get('/mines')
async def getMines():
  return mines
   
# Getting a specific mine
@app.get('/mines/{id}')
async def getMine(id: str):
   print(mines[id])
   return {'id': id, 'coords': mines[id]}

# Deleting a specific mine
@app.delete('/mines/{id}')
async def deleteMine(id: str):
    global mines
    item = mines.get(id)
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    del mines[id]
    return {"message": "Mine deleted successfully"}

class Mine(BaseModel):
   serialNum: str
   row: str
   col: str

# Creating a specific mine
@app.post('/mines')
async def createMine(mine: Mine):
  global mines
  mineDict = mine.model_dump()
  print(mineDict)
  mines[mineDict['serialNum']] = {'row': mineDict['row'], 'col': mineDict['col']}

  return {"message": f"Mine with id {mineDict['serialNum']} created successfully"}

# Updating a specific mine
@app.put('/mines')
async def updateMine(serialNum: str, row: int, col: int):
  global mines
  item = mines.get(serialNum)
  if not item:
      raise HTTPException(status_code=404, detail="Item not found")
  
  mines[serialNum]['row'] = row
  mines[serialNum]['col'] = col

  return {serialNum: mines[serialNum]}


# Retrieving a list of all rovers
@app.get('/rovers')
async def getRovers():
  return rovers

# Retrieving a specific rover
@app.get('/rovers/{id}')
async def getRovers(id: int):
  global rovers
  rover = rovers.get(id)
  if not rover:
      raise HTTPException(status_code=404, detail="Rover not found")
  return rover

# Creating a rover
@app.post('/rovers')
async def createRover(id: int, commands: str):
   global rovers
   if rovers.get(id):
      raise HTTPException(status_code=404, detail=f"Rover with id: {id} already exists")
   
   rovers[id] = {'id': id, 'commands': commands, 'status': 'Not Started', 'position': (0, 0), 
                 'executedCommands': []}

   return rovers[id]

# Deleting a rover
@app.delete('/rovers/{id}')
async def deleteRover(id: int):
    global rovers
    rover = rovers.get(id)
    if not rover:
        raise HTTPException(status_code=404, detail="Rover not found")
    del rover[id]
    return {"message": "Rover deleted successfully"}


# Sending list of commands to rover
@app.put('/rovers/{id}')
async def updateRover(id: int, commands: str):
  global rovers
  rover = rovers.get(id)

  if not rover:
    raise HTTPException(status_code=404, detail="Rover not found")
  if rover['status'] == 'Moving' or rover['status'] == 'Eliminated':
    raise HTTPException(status_code=406, detail='Rover failure')
  
  rover['commands'] = commands
  return {"message": "Rover updated successfully"}


# Dispatching a rover
@app.post('/rovers/{id}/dispatch')
async def dispatchRover(id: int):
  rover = rovers.get(id)

  if not rover:
    raise HTTPException(status_code=404, detail="Rover not found")


  return {'id': rover['id'], 'status': rover['status'], 
          'position': rover['position'], 'executedCommands': rover['executedCommands']} 
  
