import pika
import json
from threading import Thread
from time import sleep

# docker run -d --name AirTrafficControl -p 5672:5672 -p 5673:5673 -p 15672:15672 rabbitmq:3-management  
runways = [{'Name': 'Runway 1', 'Plane Type': ['Class A', 'Class B'], 'Plane Weight': 800000, 'In use': False},
           {'Name': 'Runway 2', 'Plane Type': ['Class A', 'Class B', 'Class C'], 'Plane Weight': 500000, 'In use': False},
           {'Name': 'Runway 3', 'Plane Type': ['Class A', 'Class B'], 'Plane Weight': 200000, 'In use': False},
           {'Name': 'Runway 4', 'Plane Type': ['Class C'], 'Plane Weight': 200000, 'In use': False}]

                                  
def main():
    # Create landing / takeoff request exchange
    connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))     
    channel = connection.channel()  
    channel.exchange_declare(
      exchange='requests',
      exchange_type='direct'
    )


    # Create takeoff / landing channel 
    queue = channel.queue_declare('takeoff_landing')
    queue_name = queue.method.queue
    channel.queue_bind(
      exchange='requests',
      queue=queue_name,
      routing_key='request'
    )

    channel.basic_consume(on_message_callback=runwayCallback, queue=queue_name)
    print('Checking for landing / takeoff requests...')    
    channel.start_consuming()


def runwayCallback(ch, method, props, body):
  payload = json.loads(body)
  ch.basic_ack(delivery_tag=method.delivery_tag)
  print(f'Request for {payload['request']} received from {payload['callSign']}. Assigning runway...')
  type = payload['type']
  weight = payload['weight']
  duration = payload['duration']

  for runway in runways:
     if type in runway['Plane Type'] and weight <= runway['Plane Weight'] and not runway['In use']:
        designtatedRunway = runway['Name']
        ch.basic_publish(exchange='',
                     routing_key=props.reply_to,
                     properties=pika.BasicProperties(correlation_id = \
                                                         props.correlation_id),
                     body=json.dumps({'Designated Runway' : designtatedRunway})
        )
        
        print(f'Runway {designtatedRunway} assigned.')
        # Now lock the runway for that amount of time 
        # Making Pika connection threadsafe
        thread = Thread(target=lockRunway, args=(duration, runway))
        thread.start()

        return
  # If no available runway currently
  ch.basic_publish(exchange='',
                     routing_key=props.reply_to,
                     properties=pika.BasicProperties(correlation_id = \
                                                         props.correlation_id),
                     body=json.dumps({'Designated Runway' : 'Not Available. Please circle around.'})
        )



def lockRunway(duration, runway):
  connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))     
  ch = connection.channel()  

  ch.basic_publish(exchange='requests',
                   routing_key='runway',
                   body=json.dumps({'Name' : runway['Name'], 'Duration': duration})
  )

  runway['In use'] = True
  sleep(duration)
  runway['In use'] = False



  
    

if __name__ == "__main__":
    main()
