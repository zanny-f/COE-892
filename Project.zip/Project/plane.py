from Airplane import Airplane

maxWeight = 800000
def main():
    type = input('Plane type: ')
    if type not in Airplane.planeTypes:
       print('Not a valid plane')
       return
    weight = int(input('Plane weight: '))
    if weight > maxWeight:
       print('Plane too heavy!')
       return
    callSign = input('Call Sign: ')
    landingDuration = int(input('Landing duration (seconds): '))
    takeoffDuration = int(input('Takeoff duration (seconds): '))
    airplane = Airplane(type, weight, callSign)


    print("\nCommands: 1. Landing Request, 2. Takeoff Request")
    while(1):
      option = int(input('Enter command: '))
      if option == 1:
        airplane.request(Airplane.requestType[0], landingDuration)
      elif option == 2:
        airplane.request(Airplane.requestType[1], takeoffDuration)
      else:
        print('Not a valid option.')



        

if __name__ == "__main__":
    main()

