import uuid
import pika
import json

class Airplane():
   statusCodes = ['Parked', 'Taxiing', 'Taking Off', 'In Flight', 'Landing' 'Mayday']
   requestType = ['Takeoff', 'Landing']
   planeTypes = ['Class A', 'Class B', 'Class C']
   
   def __init__(self, planeType, weight, callSign):
      self.planeType = planeType
      self.weight = weight
      self.callSign = callSign
      self.status = Airplane.statusCodes[1]


      self.connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))
      self.channel = self.connection.channel()
      response = self.channel.queue_declare(queue='', exclusive=True)
      self.callback_queue = response.method.queue
      self.channel.basic_consume(
         queue=self.callback_queue,
         on_message_callback=self.on_response,
         auto_ack=True
      )

   def request(self, requestType, duration):
      self.response = None
      self.corr_id = str(uuid.uuid4())
      self.channel.basic_publish(
            exchange='requests',
            routing_key='request',
            properties=pika.BasicProperties(
                reply_to=self.callback_queue,
                correlation_id=self.corr_id,
            ),
            body=json.dumps({'request' : requestType, 'type': self.planeType, 'weight': self.weight, 'callSign': self.callSign, 'duration': duration})
      )

      while self.response is None:
            self.connection.process_data_events(time_limit=None)
       

   def on_response(self, ch, method, props, body):
        if self.corr_id == props.correlation_id:
            self.response = body
            payload = json.loads(body)
            print(payload)