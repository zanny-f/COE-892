
import warnings
from tqdm import tqdm
warnings.filterwarnings("ignore")
import time
from threading import Thread
import pika
import json

def main():
  # Define progress bar titles, total lengths, and format string
  print('RUNWAY STATUS: ')
  bar_titles = ["Runway 1", "Runway 2", "Runway 3", "Runway 4"]
  format_string = '{l_bar}{bar}| [{elapsed}<{remaining}]'

  # Create progress bars with titles, total lengths, and format string
  global progress_bars 
  progress_bars = {title: tqdm(desc=title, bar_format=format_string) for title in bar_titles}

  connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
  channel = connection.channel()  
  # Create runway status channel
  queue = channel.queue_declare('runways')
  queue_name = queue.method.queue
  channel.queue_bind(
    exchange='requests',
    queue=queue_name,
    routing_key='runway'
  )

  channel.basic_consume(on_message_callback=progressBarThread, queue=queue_name) 
  channel.start_consuming()
  
  # Close progress bars
  for bar in progress_bars:
    bar.close()

def progressBarThread(ch, method, properties, body):
  payload = json.loads(body)
  ch.basic_ack(delivery_tag=method.delivery_tag)
  
  thread = Thread(target=startProgressBar, args=(progress_bars[payload['Name']], payload['Duration'], payload['Name']))
  thread.start()



def startProgressBar(progressBar, duration, runwayName):
  progressBar.reset(total=duration)
  progressBar.set_description(f'{runwayName} (IN USE)')
  start_time = time.time()
  while time.time() - start_time < duration:
    # Simulate some work here (replace with your actual work)
    time.sleep(0.01)  # Short sleep to update progress bar
    progressBar.update(0.01)  # Update progress bar by a small amount
  progressBar.reset()
  progressBar.set_description(f'{runwayName} (CLEAR)')


if __name__ == "__main__":
    main()