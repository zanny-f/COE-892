from concurrent import futures
import grpc
import rover_pb2
import rover_pb2_grpc

class RoverService(rover_pb2_grpc.RoverServiceServicer):
    def GetMap(self, request, context):
        with open("map.txt", "r") as file:
            map_data = file.read().splitlines()[1:]
        return rover_pb2.MapResponse(mapRows=map_data)

    def GetCommands(self, request, context):
        rover_id = request.rover_id
        try:
            with open(f"command_{rover_id}.txt", "r") as file:
                commands = file.read().strip()
                for command in commands:
                    yield rover_pb2.CommandResponse(command=command)
        except FileNotFoundError:
            context.abort(grpc.StatusCode.NOT_FOUND, f"Commands for Rover {rover_id} not found.")

    def GetMineSerial(self, request, context):
        with open("mines.txt", "r") as file:
            serial_number = int(file.read().split()[1])  # Example: Read the first mine's serial
        return rover_pb2.MineSerialResponse(serialNumber=serial_number)

    def ReportExecutionStatus(self, request, context):
        return rover_pb2.ExecutionStatusResponse(message="Report Received")

    def ShareMinePIN(self, request, context):
        # Implement logic to share the mine PIN here
        return rover_pb2.MinePINResponse(message="PIN Shared Successfully")

def serve():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    rover_pb2_grpc.add_RoverServiceServicer_to_server(RoverService(), server)
    server.add_insecure_port('[::]:50051')
    server.start()
    server.wait_for_termination()

if __name__ == '__main__':
    serve()
