import grpc
import rover_pb2
import rover_pb2_grpc
import sys

def run(rover_id):
    with grpc.insecure_channel('localhost:50051') as channel:
        stub = rover_pb2_grpc.RoverServiceStub(channel)

        map_response = stub.GetMap(rover_pb2.MapRequest())
        map_data = [list(map(int, row.split())) for row in map_response.mapRows]
        print("Map Data:", map_data)

        commands = []
        for command_response in stub.GetCommands(rover_pb2.CommandRequest(rover_id=rover_id)):
            commands.append(command_response.command)
        print("Commands:", ''.join(commands))

        # Example execution of commands (implementation depends on command specifics)
        # For demonstration, we simply print the commands
        # Implement the actual logic based on your requirements

        # Get the mine serial number (assuming we encountered a mine)
        mine_serial_response = stub.GetMineSerial(rover_pb2.MineSerialRequest())
        print("Mine Serial:", mine_serial_response.serialNumber)

        # Share the mine PIN (hardcoded as an example)
        mine_pin_response = stub.ShareMinePIN(rover_pb2.MinePINRequest(serialNumber=mine_serial_response.serialNumber, pin=1234))
        print(mine_pin_response.message)

        status_response = stub.ReportExecutionStatus(rover_pb2.ExecutionStatusRequest(rover_id=rover_id, success=True))
        print(status_response.message)

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print("Usage: python client.py <rover_id>")
        sys.exit(1)

    rover_id = int(sys.argv[1])
    run(rover_id)
