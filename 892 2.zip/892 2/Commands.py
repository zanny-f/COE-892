import requests
import json

for i in range(1,11):
    
    filename = f'command_{i}.txt'
    URL = "https://coe892.reev.dev/lab1/rover/" + str(i)
    response = requests.get(URL)
    data = response.json()
    # data = response.text
    # y = json.loads(data)
    moves = [data.get("data")]
    y=moves[0]["moves"]
    # Opening the file for writing
    with open(filename, 'w') as file:
        # Writing a unique line of text to each file
        file.write(str(y))
        print(str(y),i)
