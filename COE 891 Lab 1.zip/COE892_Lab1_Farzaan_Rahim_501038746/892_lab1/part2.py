import hashlib
import time
import threading

# file = open('mine.txt', 'r')
# map = file.read()
# # print(map)
#
# arr = [[0, 1, 0],
#        [0, 0, 0],
#        [1, 0, 0],
#        [0, 0, 0]]
# mine_x=0
# mine_y=0
# mineLoaction = []
# for r in arr:
#     mine_y += 1
#     for c in r:
#         mine_x += 1
#         print(end = " ")
#         if c == 1:
#             mineLoaction.append((mine_x,mine_y))
#             # print(str(mine_x)+","+str(mine_y))
#             # print(mineLoaction)
#             print(mineLoaction)
#     mine_x=0
#     # print()


# Function to check if the pin is valid for disarming the mine
def is_valid_pin(serial, pin):
    temp_key = f'{pin}{serial}'
    hashed_key = hashlib.sha256(temp_key.encode()).hexdigest()
    return hashed_key.startswith('000000')

# Function to find a valid pin for a mine
def find_valid_pin(serial):
    pin = 0
    while not is_valid_pin(serial, str(pin)):
        pin += 1
    return pin

# Sequential approach to disarm mines
def main_sequential():
    start_time = time.time()
    with open('mine.txt', 'r') as file:
        lines = file.readlines()
        for i, line in enumerate(lines[1:], 1):  # Assuming first line is a header or irrelevant
            for j, cell in enumerate(line.strip()):
                if cell == '1':  # Mine detected
                    serial = f'{i}-{j}'
                    valid_pin = find_valid_pin(serial)
                    print(f'Mine at ({i}, {j}) with serial {serial} disarmed with PIN {valid_pin}')
    end_time = time.time()
    print(f"Total time for sequential approach: {end_time - start_time} seconds")

# Function to disarm a mine for parallel execution
def disarm_mine_parallel(serial):
    valid_pin = find_valid_pin(serial)
    print(f'Mine with serial {serial} disarmed with PIN {valid_pin}')

# Parallel approach to disarm mines
def main_parallel():
    start_time = time.time()
    threads = []
    with open('mine.txt', 'r') as file:
        lines = file.readlines()
        for i, line in enumerate(lines[1:], 1):
            for j, cell in enumerate(line.strip()):
                if cell == '1':  # Mine detected
                    serial = f'{i}-{j}'
                    thread = threading.Thread(target=disarm_mine_parallel, args=(serial,))
                    threads.append(thread)
                    thread.start()
    for thread in threads:
        thread.join()
    end_time = time.time()
    print(f"Total time for parallel approach: {end_time - start_time} seconds")

# Run both approaches
print("Running sequential approach...")
main_sequential()
print("\nRunning parallel approach...")
main_parallel()
